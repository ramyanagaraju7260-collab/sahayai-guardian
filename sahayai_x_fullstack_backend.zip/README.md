# SahayAI X

SahayAI X is a frontend plus AI backend emergency intelligence stack. The existing frontend remains unchanged in `src/`, and the production-style backend now lives in [`sahayai_x_ai`](/c:/Users/HP/Desktop/sahayai-guardian/sahayai_x_ai).

## Architecture

```text
Frontend (Vite/TanStack)
        |
        v
FastAPI API + WebSocket
        |
        +--> Accident detector
        +--> Fall detector
        +--> Voice panic detector
        +--> Vision analyzers
        +--> NLP emergency classifier
        +--> Sensor fusion engine
        +--> Severity predictor
        +--> Response agents
```

## Run

Backend only:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m sahayai_x_ai.scripts.run_backend
```

Frontend + backend together in one command:

```bash
python -m sahayai_x_ai.scripts.run_full_stack
```

Docker:

```bash
docker-compose up --build
```

## API

- `POST /api/detect/accident`
- `POST /api/detect/fall`
- `POST /api/detect/emergency`
- `POST /api/classify/emergency`
- `POST /api/predict/severity`
- `POST /api/vision/analyze`
- `POST /api/voice/analyze`
- `POST /api/nlp/classify`
- `POST /api/agent/orchestrate`
- `POST /api/agent/guidance`
- `POST /api/agent/support`
- `GET /api/analytics/heatmap`
- `GET /api/analytics/stats`
- `GET /api/health`
- `WS /ws/realtime/{user_id}`

Example:

```bash
curl -X POST http://localhost:8000/api/detect/accident ^
  -H "Content-Type: application/json" ^
  -d "{\"sensor_window\": [[0.1,0.2,1,0,0,0,12]$(for /l %i in (2,1,50) do @echo , [0.1,0.2,1,0,0,0,12])], \"timestamp\": \"2026-01-01T00:00:00\"}"
```

## Models

- Auto-train on first startup if cached artifacts are missing.
- Cached artifacts are stored under [`sahayai_x_ai/model_cache`](/c:/Users/HP/Desktop/sahayai-guardian/sahayai_x_ai/model_cache).
- Synthetic data generators are under [`sahayai_x_ai/data/synthetic`](/c:/Users/HP/Desktop/sahayai-guardian/sahayai_x_ai/data/synthetic).

## Demo and Tests

Run the demo sweep:

```bash
python -m sahayai_x_ai.demo_test
```

Run tests:

```bash
pytest sahayai_x_ai/tests -q
```

## Notes

- The backend is intentionally self-healing: it trains synthetic fallback models if no cache is present.
- The frontend code was not modified.
- The original notebook request was converted into runnable Python analysis scripts in [`sahayai_x_ai/notebooks`](/c:/Users/HP/Desktop/sahayai-guardian/sahayai_x_ai/notebooks) because you explicitly asked for `.py` files instead of `.ipynb`.
