import { createFileRoute } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { useEmergencyStore } from "@/store/emergency";
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, LineChart, Line, Area, AreaChart } from "recharts";
import { useEffect, useState } from "react";
import { TrendingUp, AlertTriangle, Clock, HeartHandshake, Activity } from "lucide-react";

export const Route = createFileRoute("/analytics")({
  head: () => ({ meta: [{ title: "Intel · SahayAI X" }] }),
  component: Analytics,
});

const typeData = [
  { name: "Accidents", value: 34, color: "oklch(0.66 0.24 25)" },
  { name: "Medical", value: 28, color: "oklch(0.66 0.22 350)" },
  { name: "Fire", value: 18, color: "oklch(0.78 0.17 45)" },
  { name: "Violence", value: 12, color: "oklch(0.55 0.22 280)" },
  { name: "Other", value: 8, color: "oklch(0.78 0.16 175)" },
];

const hourly = Array.from({ length: 24 }, (_, h) => ({
  hour: `${h}h`,
  count: Math.round(20 + Math.sin(h / 3) * 15 + Math.random() * 10 + (h >= 17 && h <= 22 ? 25 : 0)),
}));

const accuracyData = [87, 89, 91, 93, 90, 94, 96].map((v, i) => ({ day: `D${i + 1}`, acc: v }));

function Analytics() {
  const { incidents } = useEmergencyStore();
  const [heatmap, setHeatmap] = useState(() =>
    Array.from({ length: 100 }, () => Math.random())
  );
  const [feed, setFeed] = useState(incidents);

  useEffect(() => {
    const id = setInterval(() => {
      setHeatmap((h) => h.map((v) => Math.max(0, Math.min(1, v + (Math.random() - 0.5) * 0.3))));
    }, 2000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      const samples = ["Accident detected", "Fall detected", "Voice panic", "Fire alert", "Medical alert"];
      const places = ["Indiranagar", "HSR Layout", "Whitefield", "Koramangala", "MG Road", "Jayanagar"];
      const sev = ["HIGH", "CRITICAL", "MEDIUM"] as const;
      setFeed((f) => [{
        id: crypto.randomUUID(),
        type: samples[Math.floor(Math.random() * samples.length)],
        location: places[Math.floor(Math.random() * places.length)] + ", Bengaluru",
        severity: sev[Math.floor(Math.random() * sev.length)],
        status: "ACTIVE" as const,
        ts: Date.now(),
      }, ...f].slice(0, 18));
    }, 7000);
    return () => clearInterval(id);
  }, []);

  return (
    <Layout>
      <div className="px-4 lg:px-8 py-6 max-w-[1400px] mx-auto space-y-5">
        <div>
          <div className="mono text-[11px] text-muted-foreground tracking-widest"><Activity className="w-3 h-3 inline mr-1 text-safe" /> EMERGENCY INTELLIGENCE COMMAND</div>
          <h1 className="font-display text-3xl lg:text-4xl font-bold text-gradient">War Room · Live</h1>
        </div>

        {/* metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: "Emergencies Today", val: "127", trend: "+12%", icon: AlertTriangle, color: "oklch(0.66 0.24 25)" },
            { label: "Avg Response", val: "4.2 min", trend: "-8%", icon: Clock, color: "oklch(0.78 0.16 175)" },
            { label: "Lives Impacted", val: "89", trend: "+23%", icon: HeartHandshake, color: "oklch(0.85 0.18 340)" },
            { label: "Active SOS", val: "3", trend: "LIVE", icon: TrendingUp, color: "oklch(0.66 0.24 25)", live: true },
          ].map((m, i) => (
            <div key={i} className="panel p-4 relative overflow-hidden">
              {m.live && <span className="absolute top-3 right-3 w-2 h-2 rounded-full bg-primary glow-danger animate-pulse" />}
              <m.icon className="w-5 h-5" style={{ color: m.color }} />
              <div className="font-display text-3xl font-bold mt-3">{m.val}</div>
              <div className="mono text-[10px] text-muted-foreground tracking-widest mt-1">{m.label}</div>
              <div className="mono text-[10px] mt-1" style={{ color: m.color }}>{m.trend}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* donut */}
          <div className="panel p-5">
            <h3 className="font-display text-base font-semibold">Type Distribution</h3>
            <p className="mono text-[10px] text-muted-foreground mb-2">LAST 24H</p>
            <div className="h-52">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={typeData} dataKey="value" innerRadius={50} outerRadius={75} paddingAngle={3}>
                    {typeData.map((d, i) => <Cell key={i} fill={d.color} stroke="transparent" />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "oklch(0.18 0.014 255)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-1.5 mt-2">
              {typeData.map((d, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <span className="w-2 h-2 rounded-sm" style={{ background: d.color }} />
                  <span className="text-muted-foreground">{d.name}</span>
                  <span className="ml-auto mono">{d.value}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* hourly */}
          <div className="panel p-5 lg:col-span-2">
            <h3 className="font-display text-base font-semibold">Hourly Frequency</h3>
            <p className="mono text-[10px] text-muted-foreground mb-2">PEAK HOURS HIGHLIGHTED</p>
            <div className="h-52">
              <ResponsiveContainer>
                <BarChart data={hourly}>
                  <XAxis dataKey="hour" tick={{ fill: "oklch(0.7 0.018 260)", fontSize: 10, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "oklch(0.7 0.018 260)", fontSize: 10, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{ fill: "oklch(1 0 0 / 0.04)" }} contentStyle={{ background: "oklch(0.18 0.014 255)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 12 }} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {hourly.map((d, i) => (
                      <Cell key={i} fill={d.count > 50 ? "oklch(0.66 0.24 25)" : "oklch(0.55 0.18 250)"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* heatmap */}
          <div className="panel p-5 lg:col-span-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold">City Danger Heatmap</h3>
                <p className="mono text-[10px] text-muted-foreground">10×10 GRID · UPDATING 2s</p>
              </div>
              <div className="mono text-[10px] flex items-center gap-2">
                <span>LOW</span>
                <span className="w-24 h-2 rounded-full bg-gradient-to-r from-safe via-warn to-primary" />
                <span>HIGH</span>
              </div>
            </div>
            <div className="grid grid-cols-10 gap-1.5 mt-4">
              {heatmap.map((v, i) => {
                const c = v < 0.33 ? "oklch(0.78 0.16 175)" : v < 0.66 ? "oklch(0.78 0.17 65)" : "oklch(0.66 0.24 25)";
                return (
                  <div key={i} className="aspect-square rounded-md transition-all duration-700 hover:scale-110 hover:z-10 cursor-pointer relative group"
                    style={{ background: c, opacity: 0.25 + v * 0.75, boxShadow: v > 0.7 ? `0 0 12px ${c}` : "none" }}
                    title={`Zone ${String.fromCharCode(65 + (i % 10))}${Math.floor(i / 10) + 1} — ${Math.round(v * 12)} incidents`}
                  />
                );
              })}
            </div>
          </div>

          {/* accuracy */}
          <div className="panel p-5">
            <h3 className="font-display text-base font-semibold">AI Detection Accuracy</h3>
            <p className="mono text-[10px] text-muted-foreground mb-2">7 DAY TREND</p>
            <div className="h-52">
              <ResponsiveContainer>
                <AreaChart data={accuracyData}>
                  <defs>
                    <linearGradient id="acc" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.78 0.16 175)" stopOpacity="0.6" />
                      <stop offset="100%" stopColor="oklch(0.78 0.16 175)" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" tick={{ fill: "oklch(0.7 0.018 260)", fontSize: 10, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
                  <YAxis domain={[80, 100]} tick={{ fill: "oklch(0.7 0.018 260)", fontSize: 10, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "oklch(0.18 0.014 255)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 12 }} />
                  <Area type="monotone" dataKey="acc" stroke="oklch(0.78 0.16 175)" strokeWidth={2} fill="url(#acc)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 mono text-[10px] text-safe">Δ +9pts · false positives -34%</div>
          </div>
        </div>

        {/* live feed */}
        <div className="panel p-5">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-semibold">Live Emergency Feed</h3>
            <div className="mono text-[10px] flex items-center gap-1.5"><span className="status-dot danger" /> STREAMING</div>
          </div>
          <div className="mt-3 space-y-1.5 max-h-80 overflow-y-auto">
            {feed.map((i) => {
              const ago = Math.max(1, Math.round((Date.now() - i.ts) / 60000));
              const sevColor = i.severity === "CRITICAL" ? "oklch(0.66 0.24 25)" : i.severity === "HIGH" ? "oklch(0.78 0.17 65)" : "oklch(0.78 0.16 175)";
              return (
                <div key={i.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-white/5 border border-transparent hover:border-border/50">
                  <span className="w-1.5 h-1.5 rounded-full" style={{ background: sevColor, boxShadow: `0 0 8px ${sevColor}` }} />
                  <span className="mono text-[10px] text-muted-foreground w-14">{ago}m ago</span>
                  <span className="text-sm font-medium">{i.type}</span>
                  <span className="mono text-[11px] text-muted-foreground">·  {i.location}</span>
                  <span className="ml-auto mono text-[10px] px-2 py-0.5 rounded-full" style={{ background: `${sevColor}25`, color: sevColor }}>{i.severity}</span>
                  <span className="mono text-[10px] text-muted-foreground">{i.status}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Layout>
  );
}
