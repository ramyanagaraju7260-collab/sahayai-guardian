from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def main() -> None:
    backend = subprocess.Popen([sys.executable, "-m", "sahayai_x_ai.scripts.run_backend"], cwd=ROOT)
    time.sleep(2)
    frontend = subprocess.Popen(["npm", "run", "dev", "--", "--host"], cwd=ROOT)
    try:
        backend.wait()
        frontend.wait()
    except KeyboardInterrupt:
        backend.terminate()
        frontend.terminate()


if __name__ == "__main__":
    main()

