import { Outlet, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import appCss from "../styles.css?url";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: "SahayAI X — Autonomous Emergency Intelligence" },
      { name: "description", content: "AI-powered autonomous emergency intelligence — predict, detect, and respond to crises in real time." },
      { name: "theme-color", content: "#0B0F14" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Syne:wght@600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" },
      { rel: "stylesheet", href: "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" },
    ],
  }),
  shellComponent: RootShell,
  component: () => <Outlet />,
  notFoundComponent: () => (
    <div className="app-bg min-h-screen grid place-items-center">
      <div className="text-center">
        <div className="font-display text-7xl font-bold text-gradient">404</div>
        <p className="mono text-sm text-muted-foreground mt-2">SIGNAL LOST</p>
        <a href="/dashboard" className="inline-block mt-4 px-4 py-2 rounded-xl bg-primary text-primary-foreground">Return to Command</a>
      </div>
    </div>
  ),
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}
